import numpy as np
from scipy.io.wavfile import read

# Chuyển chuỗi bit thành văn bản
def bits_to_text(bits):
    chars = [bits[i:i+8] for i in range(0, len(bits), 8)]
    return ''.join(chr(int(c, 2)) for c in chars if len(c) == 8)

# Đọc dãy nhảy tần từ file
def load_hopping_pattern(input_file):
    with open(input_file, 'r') as f:
        return [int(x) for x in f.read().strip().split()]

# Giải điều chế để trích xuất thông điệp
def extract_message(stego_audio, fs, bit_length, hopping_pattern, base_freq=2000, delta=100):
    t = np.linspace(0, 0.01, int(fs * 0.01), endpoint=False)  # 10ms mỗi bit
    bits = ''
    for i in range(bit_length):
        hop = hopping_pattern[i]
        f0 = base_freq + hop * delta
        f1 = base_freq + (hop + 1) * delta
        seg = stego_audio[i*len(t):(i+1)*len(t)]
        if len(seg) != len(t):  # Bỏ qua nếu đoạn không đủ dài
            continue
        corr0 = np.sum(seg * np.sin(2 * np.pi * f0 * t))
        corr1 = np.sum(seg * np.sin(2 * np.pi * f1 * t))
        bits += '0' if corr0 > corr1 else '1'
    return bits_to_text(bits)

# Thực thi
if __name__ == "__main__":
    # Đọc file âm thanh đã nhúng tin
    fs, stego_audio = read("stego_audio.wav")
    if stego_audio.ndim > 1:  # Chuyển sang mono nếu là stereo
        stego_audio = stego_audio[:, 0]
    
    # Chuyển sang float64 và chuẩn hóa
    stego_audio = stego_audio.astype(np.float64) / 32767.0
    
    # Đọc dãy nhảy tần
    hopping_pattern = load_hopping_pattern("hopping_pattern.txt")
    
    # Đọc độ dài bit
    with open("message_bits.txt", 'r') as f:
        bits = f.read().strip()
    bit_length = len(bits)
    
    # Kiểm tra độ dài
    if len(hopping_pattern) != bit_length:
        raise ValueError("Độ dài dãy nhảy tần không khớp với độ dài chuỗi bit")
    
    # Trích xuất thông điệp
    extracted_message = extract_message(stego_audio, fs, bit_length, hopping_pattern)
    
    # Lưu thông điệp trích xuất
    with open("extracted_message.txt", 'w', encoding='utf-8') as f:
        f.write(extracted_message)
    
    print(f"Thông điệp trích xuất: {extracted_message}")
    print("Thông điệp đã được lưu vào: extracted_message.txt")