import numpy as np
from scipy.io.wavfile import write, read

# Điều chế dữ liệu bằng FSK
def modulate_fsk(bits, fs, base_freq=2000, delta=100, hopping_pattern=None):
    t = np.linspace(0, 0.01, int(fs * 0.01), endpoint=False)  # 10ms mỗi bit
    signal = np.array([])
    for i, bit in enumerate(bits):
        hop = hopping_pattern[i]
        if bit == '0':
            freq = base_freq + hop * delta
        else:
            freq = base_freq + (hop + 1) * delta
        tone = np.sin(2 * np.pi * freq * t)
        signal = np.concatenate((signal, tone))
    return signal

# Nhúng tín hiệu đã điều chế vào âm thanh gốc
def embed_message(audio, fs, bits, hopping_pattern):
    # Điều chế tín hiệu
    modulated_signal = modulate_fsk(bits, fs, base_freq=2000, delta=100, hopping_pattern=hopping_pattern)
    
    # Chuẩn hóa biên độ tín hiệu điều chế
    modulated_signal = modulated_signal * 0.5  # Giảm biên độ để tránh méo tiếng
    
    # Chuyển âm thanh gốc sang float64
    combined = audio.astype(np.float64) / 32767.0  # Chuẩn hóa về [-1, 1]
    
    # Kiểm tra độ dài
    if len(modulated_signal) > len(audio):
        raise ValueError("Tín hiệu quá dài so với âm thanh gốc")
    
    # Nhúng tín hiệu
    combined[:len(modulated_signal)] += modulated_signal
    return combined

# Đọc dãy nhảy tần từ file
def load_hopping_pattern(input_file):
    with open(input_file, 'r') as f:
        return [int(x) for x in f.read().strip().split()]

# Thực thi
if __name__ == "__main__":
    # Đọc file âm thanh gốc
    fs, original_audio = read("original_audio.wav")
    if original_audio.ndim > 1:  # Chuyển sang mono nếu là stereo
        original_audio = original_audio[:, 0]
    
    # Đọc chuỗi bit
    with open("message_bits.txt", 'r') as f:
        bits = f.read().strip()
    
    # Đọc dãy nhảy tần
    hopping_pattern = load_hopping_pattern("hopping_pattern.txt")
    
    # Kiểm tra độ dài
    if len(hopping_pattern) != len(bits):
        raise ValueError("Độ dài dãy nhảy tần không khớp với chuỗi bit")
    
    # Nhúng thông điệp
    stego_audio = embed_message(original_audio, fs, bits, hopping_pattern)
    
    # Lưu file âm thanh đã nhúng
    write("stego_audio.wav", fs, (stego_audio * 32767).astype(np.int16))
    print("File âm thanh đã nhúng tin được lưu tại: stego_audio.wav")